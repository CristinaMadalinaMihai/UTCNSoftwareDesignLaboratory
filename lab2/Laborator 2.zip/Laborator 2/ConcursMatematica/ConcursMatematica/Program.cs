﻿namespace ConcursMatematica
{
    class Program
    {              
        static void Main(string[] args)
        {
            
        }
    }
}
