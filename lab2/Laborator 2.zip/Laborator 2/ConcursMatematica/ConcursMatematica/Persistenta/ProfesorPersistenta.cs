﻿using ConcursMatematica.Model;
using System.Collections.Generic;
using System.Data;

namespace ConcursMatematica.Persistenta
{
    public class ProfesorPersistenta
    {
        private Persistenta persistenta;

        public ProfesorPersistenta()
        {
            this.persistenta = new Persistenta();
        }

        public ProfesorPersistenta(string s)
        {
            this.persistenta = new Persistenta(s);
        }

        public bool AdaugareProfesor(Profesor prof)
        {
            string comandaSQL = "insert into Profesor values('" + prof.Cnp + "','" + prof.Nume + "','" + prof.Prenume + "','" + prof.Liceu + "')";
            return this.persistenta.ComandaSQL(comandaSQL);
        }

        public bool StergereProfesor(string cnp)
        {
            string comandaSQL = "delete from Profesor where Cnp = '" + cnp + "'";
            return this.persistenta.ComandaSQL(comandaSQL);
        }

        public bool ActualizareProfesor(string cnp, Profesor prof)
        {
            string comandaSQL = "update Profesor set Nume = '" + prof.Nume + "', Prenume = '" + prof.Prenume + "', Liceu = '" + prof.Liceu + "' where Cnp = '" + cnp + "'";
            return this.persistenta.ComandaSQL(comandaSQL);
        }

        public List<Profesor> ListaProfesori()
        {
            string vizualizareSQL = "Select * from Profesor order by Nume"; 
            DataTable tabelProfesori = this.persistenta.ObtinereTabel(vizualizareSQL);
            if (tabelProfesori == null || tabelProfesori.Rows.Count == 0)
                return null;
            List<Profesor> lista = new List<Profesor>();
            foreach (DataRow dr in tabelProfesori.Rows)
            {
                Profesor prof = new Profesor((string)dr["Nume"], (string)dr["Prenume"], (string)dr["Cnp"], (string)dr["Liceu"]);
                lista.Add(prof);
            } 
            return lista;
        }       

        public Profesor CautareProfesor(string cnpProfesor)
        {
            string cautareSQL = "Select * from Profesor where Cnp = '" + cnpProfesor + "'";
            DataTable tabelProfesori = this.persistenta.ObtinereTabel(cautareSQL);
            if (tabelProfesori == null || tabelProfesori.Rows.Count == 0)
                return null;
            DataRow dr = tabelProfesori.Rows[0];
            return new Profesor(dr["Nume"].ToString(), dr["Prenume"].ToString(), dr["Cnp"].ToString(), dr["Liceu"].ToString()); 
        } 
    }
}
