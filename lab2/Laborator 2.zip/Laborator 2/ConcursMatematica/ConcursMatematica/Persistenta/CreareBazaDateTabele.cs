﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace ConcursMatematica.Persistenta
{
    public class CreareBazaDateTabele
    {

        public void CreareBazaDate()
        {
            SqlConnection conexiune = new SqlConnection("Server=localhost\\sqlexpress;Integrated security=SSPI;database=master");
            String  str = "CREATE DATABASE ConcursMatematica ON PRIMARY " +
             "(NAME = ConcursMatematica_Data, " +
             "FILENAME = 'D:\\ConcursMatematica.mdf', " +
             "SIZE = 5MB, MAXSIZE = 10MB, FILEGROWTH = 10%)" +
             "LOG ON (NAME = ConcursMatematica_Log, " +
             "FILENAME = 'D:\\ConcursMatematicaLog.ldf', " +
             "SIZE = 1MB, MAXSIZE = 5MB, FILEGROWTH = 10%)";
            SqlCommand comandaSQL = new SqlCommand(str, conexiune); 
            try
            {
                conexiune.Open(); 
                comandaSQL.ExecuteNonQuery();
                Console.WriteLine("Baza de date a fost creata cu succes!");
            }
            catch (System.Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            finally
            {
                if (conexiune.State != ConnectionState.Closed)
                    conexiune.Close();
            }
        }


        public bool CreareTabelProfesor() 
        {
            string connectionString = "Integrated Security=SSPI;Initial Catalog=ConcursMatematica;Data Source=localhost\\sqlexpress;";
            Persistenta p = new Persistenta(connectionString);
            string sql = "CREATE TABLE Profesor (Cnp CHAR(13) CONSTRAINT PKeyCnpP PRIMARY KEY, Nume CHAR(20), Prenume CHAR(30), Liceu CHAR(50))";
            bool rezultat = true;
            try
            {
                p.DeschidereConexiune();
                SqlCommand comanda = new SqlCommand(sql, p.Conexiune);
                if (comanda.ExecuteNonQuery() == 0)
                    rezultat = false;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                rezultat = false;
            }
            finally
            {
                p.InchidereConexiune();
            }
            return rezultat;
        }  
    }
}
