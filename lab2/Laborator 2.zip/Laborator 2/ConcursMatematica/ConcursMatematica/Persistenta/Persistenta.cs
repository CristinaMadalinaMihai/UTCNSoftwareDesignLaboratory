﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace ConcursMatematica.Persistenta
{
    public class Persistenta
    {
        protected SqlConnection conexiune;

        public Persistenta()
        {
            string s = "Data Source=localhost\\sqlexpress;Initial Catalog=ConcursMatematica;Integrated Security=True;";
            this.conexiune = new SqlConnection(s);
        }

        public Persistenta(string s)
        {
            this.conexiune = new SqlConnection(s);
        }

        public SqlConnection Conexiune
        {
            get { return this.conexiune; }
            set { this.conexiune = value; }
        }

        public void DeschidereConexiune()
        {
            if (this.conexiune.State != ConnectionState.Open)
                this.conexiune.Open();
        }

        public void InchidereConexiune()
        {
            if (this.conexiune.State != ConnectionState.Closed)
                this.conexiune.Close();
        }

        public bool ComandaSQL(string comandaSQL) 
        {
            bool rezultat = true;
            try
            {
                this.DeschidereConexiune();
                SqlCommand comanda = new SqlCommand(comandaSQL, this.conexiune);
                if (comanda.ExecuteNonQuery() == 0)
                    rezultat = false;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                rezultat = false;
            } 
            finally
            {
                this.InchidereConexiune();
            }
            return rezultat; 
        }

        public DataTable ObtinereTabel(string comandaSQL)
        {
            DataTable rezultat = null;
            try
            {
                this.DeschidereConexiune();
                SqlCommand comanda = new SqlCommand(comandaSQL, this.conexiune);
                SqlDataAdapter dateCitite = new SqlDataAdapter(comanda);
                DataTable dateTabel = new DataTable();
                dateCitite.Fill(dateTabel);
                rezultat = dateTabel;
            } 
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message); 
            }
            finally
            {
                this.InchidereConexiune();
            }
            return rezultat;
        }
    }
}
