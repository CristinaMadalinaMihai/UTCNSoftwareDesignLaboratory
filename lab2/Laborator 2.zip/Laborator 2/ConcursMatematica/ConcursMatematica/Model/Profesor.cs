﻿using System;

namespace ConcursMatematica.Model
{
    public class Profesor : Persoana
    {
        private string liceu;

        public Profesor() : base()
        {
            this.liceu = "Liceul Teoretic de Informatica";
        }

        public Profesor(string nume, string prenume, string cnp, string liceu)
            : base(nume, prenume, cnp)
        {
            this.liceu = liceu;
        }

        public Profesor(Profesor profesor)
        {
            this.nume = profesor.nume;
            this.prenume = profesor.prenume;
            this.cnp = profesor.cnp;
            this.liceu = profesor.liceu;
        }

        public string Liceu
        {
            get { return this.liceu; }
            set { this.liceu = value; }
        }

        public override string ToString()
        {
            return "Profesor: " + base.ToString() + " " + this.liceu;
        }

        public override bool Equals(Object obj)
        {
            if ((obj == null) || !this.GetType().Equals(obj.GetType()))
                return false;
            Profesor p = (Profesor)obj;
            return this.cnp == p.cnp;
        } 
    } 
}
