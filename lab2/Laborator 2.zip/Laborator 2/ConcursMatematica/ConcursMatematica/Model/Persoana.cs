﻿using System;

namespace ConcursMatematica.Model
{
    public class Persoana
    {
        protected string nume;
        protected string prenume;
        protected string cnp;

        public Persoana()
        {
            this.nume = "Pop";
            this.prenume = "Ioan";
            this.cnp = "1971212345678";
        }

        public Persoana(string nume, string prenume, string cnp)
        {
            this.nume = nume;
            this.prenume = prenume;
            this.cnp = cnp;
        }

        public Persoana(Persoana persoana)
        {
            this.nume = persoana.nume;
            this.prenume = persoana.prenume;
            this.cnp = persoana.cnp;
        }

        public string Nume
        {
            get { return this.nume; }
            set { this.nume = value; }
        }

        public string Prenume
        {
            get { return this.prenume; }
            set { this.prenume = value; }
        }
        public string Cnp
        {
            get { return this.cnp; }
            set { this.cnp = value; }
        }

        public override string ToString()
        {
            return this.prenume + " " + this.nume + " " + this.cnp; 
        }

        public override bool Equals(Object obj)
        {
            if ((obj == null) || !this.GetType().Equals(obj.GetType()))
                return false;
            Persoana p = (Persoana)obj;
            return this.cnp == p.cnp;
        }
    }
}
