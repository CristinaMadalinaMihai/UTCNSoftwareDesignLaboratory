﻿namespace ConcursMatematica.Model
{
    public class Proba
    {
        private string denumire;
        private float nota;

        public Proba()
        {
            this.denumire = "Geometrie";
            this.nota = 0;
        }

        public Proba(string denumire)
        {
            this.denumire = denumire;
            this.nota = 0;
        }

        public Proba(string denumire, float nota)
        {
            this.denumire = denumire;
            this.nota = nota;
        }

        public Proba(Proba proba)
        {
            this.denumire = proba.denumire;
            this.nota = proba.nota;
        }

        public string Denumire
        {
            get { return this.denumire; }
            set { this.denumire = value; }
        } 

        public float Nota
        {
            get { return this.nota; }
            set { this.nota = value; }
        }

        public override string ToString()
        {
            return "Nota la proba: " + this.denumire + " este " + this.nota;
        } 
    }
}
