﻿using System;

namespace ConcursMatematica.Model
{
    public class Elev : Persoana
    {
        private uint clasa;
        private Proba[] probe;       
        private float punctaj;
        private Profesor profesorCoordonator;

        public Elev() : base()
        {
            this.clasa = 9;
            this.probe = new Proba[3];
            this.punctaj = 0;
        }

        public Elev(string nume, string prenume, string cnp, uint clasa) 
            : base(nume, prenume, cnp)
        {
            this.clasa = clasa;
            this.probe = new Proba[3];
            this.punctaj = 0; 
        }

        public Elev(string nume, string prenume, string cnp, uint clasa, Proba[] probe) 
            : base(nume, prenume, cnp)
        {
            this.clasa = clasa;
            this.probe = new Proba[3];
            for (int i = 0; i < 3; i++)
                this.probe[i] = probe[i];
        }

        public Elev(Elev elev)
        {
            this.nume = elev.nume;
            this.prenume = elev.prenume;
            this.cnp = elev.cnp;
            this.clasa = elev.clasa;
            this.probe = new Proba[3];
            for (int i = 0; i < 3; i++)
                this.probe[i] = elev.probe[i];
            this.determinarePunctaj();
        }

        public uint Clasa
        {
            get { return this.clasa; }
            set { this.clasa = value; }
        }

        public Proba[] Probe
        {
            get { return this.probe; }
            set { this.probe = value; }
        }
        public float Punctaj
        {
            get { return this.punctaj; }
        }

        public override string ToString()
        {
            string s = base.ToString() + " Clasa = " + this.clasa;
            for (int i = 0; i < 3; i++)
                s += " " + this.probe[i].ToString();
            return s;
        }

        public override bool Equals(Object obj)
        {
            if ((obj == null) || !this.GetType().Equals(obj.GetType()))
                return false;
            Elev e = (Elev)obj;
            return this.cnp == e.cnp;
        }

        private void determinarePunctaj()
        {
            this.punctaj = (this.probe[0].Nota + this.probe[1].Nota + this.probe[2].Nota) / 3;
        }
    }
}
