﻿using NUnit.Framework;
using ConcursMatematica.Persistenta;
using System.Data;

namespace TestConcursMatematica
{
    [TestFixture]
    public class TestPersistenta
    {
        [Test]
        public void TestDeschidereConexiune()
        {
            // Arrange 
            Persistenta p = new Persistenta();
            // Act
            p.DeschidereConexiune();
            // Assert
            Assert.IsTrue(p.Conexiune.State == ConnectionState.Open); 
        }

        [Test]
        public void TestInchidereConexiune()
        {
            // Arrange
            Persistenta p = new Persistenta();
            // Act
            p.InchidereConexiune();
            // Assert
            Assert.IsTrue(p.Conexiune.State == ConnectionState.Closed);
        }

        [Test]
        public void TestComandaSQL()
        {
            // Arrange
            Persistenta p = new Persistenta();
            string comandaSQL1 = "insert into Profesor values('1981011234565','Pop','Ioan','LTNB')";
            string comandaSQL2 = "insert into Profesor values('Pop','Ioan','LTNB')";
            string comandaSQL3 = "delete from Profesor where Cnp = '1921011234565'";
            string comandaSQL4 = "delete from Profesor where Cnp = '1981011234565'";

            // Act
            bool rezultat1 = p.ComandaSQL(comandaSQL1);
            bool rezultat2 = p.ComandaSQL(comandaSQL2);
            bool rezultat3 = p.ComandaSQL(comandaSQL3);
            bool rezultat4 = p.ComandaSQL(comandaSQL4);

            // Assert
            Assert.IsTrue(rezultat1);
            Assert.IsFalse(rezultat2);
            Assert.IsFalse(rezultat3);
            Assert.IsTrue(rezultat4);
        }

        [Test]
        public void TestObtinereDate()
        {
            // Arrange
            Persistenta p = new Persistenta();
            string vizualizareSQL = "Select * from Profesor order by Nume";

            // Act
            DataTable rezultat = p.ObtinereTabel(vizualizareSQL);

            // Assert
            Assert.IsNotNull(rezultat);
            Assert.AreEqual(1, rezultat.Rows.Count);
            Assert.AreEqual(4, rezultat.Columns.Count);
        }
    }
}
