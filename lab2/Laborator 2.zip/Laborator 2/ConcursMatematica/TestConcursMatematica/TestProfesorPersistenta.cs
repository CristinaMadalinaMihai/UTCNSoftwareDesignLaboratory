﻿using System.Collections.Generic;
using NUnit.Framework;
using ConcursMatematica.Persistenta;
using ConcursMatematica.Model;

namespace TestConcursMatematica
{
    
    public class TestProfesorPersistenta
    {
        
        [Test]
        public void TestAdaugareProfesor()
        {
            // Arrange
            ProfesorPersistenta pp = new ProfesorPersistenta();
            Profesor prof = new Profesor("Pop", "Vlad", "1981011234565", "LTNB");
            // Act
            bool rezultat1 = pp.AdaugareProfesor(prof);
            bool rezultat2 = pp.AdaugareProfesor(prof);
            // Assert
            Assert.IsTrue(rezultat1);
            Assert.IsFalse(rezultat2);
        }

        [Test]
        public void TestActualizareProfesor()
        {
            // Arrange
            ProfesorPersistenta pp = new ProfesorPersistenta();
            Profesor prof = new Profesor("Popescu", "Ionel", "1981011234565", "LTNB");
            // Act
            bool rezultat1 = pp.ActualizareProfesor("1981011234565",prof);
            bool rezultat2 = pp.ActualizareProfesor("1988011234565", prof);
            // Assert
            Assert.IsTrue(rezultat1);
            Assert.IsFalse(rezultat2);
        }

        [Test]
        public void TestStergereProfesor()
        {
            // Arrange
            ProfesorPersistenta pp = new ProfesorPersistenta();
            // Act
            bool rezultat1 = pp.StergereProfesor("2981331234565");
            bool rezultat2 = pp.StergereProfesor("1981011234565");
            // Assert
            Assert.IsFalse(rezultat1);
            Assert.IsTrue(rezultat2);
        }

        [Test]
        public void TestListaProfesori()
        {
            // Arrange                        
            ProfesorPersistenta pp = new ProfesorPersistenta();
            Profesor prof1 = new Profesor("Ionescu", "Lucia", "2961021234565", "CND");
            Profesor prof2 = new Profesor("Pop", "Vlad", "1981011234565", "LTNB");           
            // Act
            List<Profesor> rezultat = pp.ListaProfesori();
            // Assert
            Assert.IsNotNull(rezultat);
            Assert.AreEqual(2, rezultat.Count);
            Assert.AreEqual(prof1, rezultat[0]);
            Assert.AreEqual(prof2, rezultat[1]);
        }

        [Test]
        public void TestCautareProfesor()
        {
            // Arrange                        
            ProfesorPersistenta pp = new ProfesorPersistenta();
            Profesor prof1 = new Profesor("Ionescu", "Lucia", "2961021234565", "CND");
            Profesor prof2 = new Profesor("Pop", "Vlad", "1981011234565", "LTNB");
            // Act
            Profesor rezultat1 = pp.CautareProfesor("2961021234565");
            Profesor rezultat2 = pp.CautareProfesor("1981011234577");
            // Assert
            Assert.IsNotNull(rezultat1);
            Assert.IsNull(rezultat2);
        }

    }
}
