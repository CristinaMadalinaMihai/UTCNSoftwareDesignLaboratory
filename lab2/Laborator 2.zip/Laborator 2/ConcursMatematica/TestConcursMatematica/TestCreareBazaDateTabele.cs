using NUnit.Framework;
using ConcursMatematica.Persistenta;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace TestConcursMatematica
{
    [TestFixture]
    public class TestCreareBazaDateTabele
    {
        [Test]
        public void TestCreareBazaDate()
        {
            // Arrange
            CreareBazaDateTabele bd = new CreareBazaDateTabele();           
            // Assert
            FileAssert.DoesNotExist("D:\\ConcursMatematica1.mdf");
            FileAssert.DoesNotExist("D:\\ConcursMatematicaLog1.ldf");
            // Act
            bd.CreareBazaDate();
            // Assert
            FileAssert.Exists("D:\\ConcursMatematica1.mdf");
            FileAssert.Exists("D:\\ConcursMatematicaLog1.ldf");
        }

        [Test]
        public void TestCreareTabelProfesor()
        {
            // Arrange
            CreareBazaDateTabele bd = new CreareBazaDateTabele();
            string s = "Data Source=localhost\\sqlexpress;Initial Catalog=ConcursMatematica;Integrated Security=True;";                
            // Act
            bd.CreareTabelProfesor();
            // Arrange
            SqlConnection conexiune = new SqlConnection(s);
            conexiune.Open();
            DataTable dt = conexiune.GetSchema("Tables");
            List<string> tabele = new List<string>();
            foreach (DataRow row in dt.Rows) 
                tabele.Add(row[2].ToString());
            bool rezultat1 = tabele.Contains("Profesor"); 
            bool rezultat2 = tabele.Contains("Profesori");
            string sqlComanda = "SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE table_name = 'Profesor'";
            SqlCommand comanda = new SqlCommand(sqlComanda, conexiune);
            int numarColoane = (int)comanda.ExecuteScalar();
            string sqlComanda1 = "SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE table_name = 'Profesor'";
            comanda = new SqlCommand(sqlComanda1, conexiune);
            SqlDataReader coloane = comanda.ExecuteReader();
            List<string> listaColoane = new List<string>();
            while (coloane.Read())
                listaColoane.Add(string.Format("{0} ", coloane[3]).Trim(' '));
            coloane.Close();
            // Assert
            Assert.IsTrue(rezultat1);
            Assert.IsFalse(rezultat2);
            Assert.AreEqual(4, numarColoane);
            Assert.AreEqual("Cnp", listaColoane[0]);
            Assert.AreEqual("Nume", listaColoane[1]);
            Assert.AreEqual("Prenume", listaColoane[2]);
            Assert.AreEqual("Liceu", listaColoane[3]);
        }
    }
}