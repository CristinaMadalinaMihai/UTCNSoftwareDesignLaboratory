﻿using System;

namespace ExempluMVVM.Model
{
    public class Persoana 
    {
        private string cnp;
        private string nume;
        private byte varsta;

        public Persoana()
        {
            this.nume = "";
            this.cnp = "";
            this.varsta = 0;
        }

        public Persoana(string nume, string cnp, byte varsta)
        {
            if (nume == null)
                throw new ArgumentNullException("Nume inexistent!");
            else if (nume.Trim() == "")
                throw new ArgumentException("Nume inexistent!");
            if (cnp == null)
                throw new ArgumentNullException("CNP inexistent!");
            else if (cnp.Trim() == "")
                throw new ArgumentException("CNP inexistent!");
            this.nume = nume;
            this.cnp = cnp;
            this.varsta = varsta;
        }

        public Persoana(Persoana persoana)
        {
            if (persoana.nume == null)
                throw new ArgumentNullException("Nume inexistent!");
            else if (persoana.nume.Trim() == "")
                throw new ArgumentException("Nume inexistent!");
            if (persoana.cnp == null)
                throw new ArgumentNullException("CNP inexistent!");
            else if (persoana.cnp.Trim() == "")
                throw new ArgumentException("CNP inexistent!");
            this.nume = persoana.nume;
            this.cnp = persoana.cnp;
            this.varsta = persoana.varsta;
        }
        public string Cnp
        {
            get { return this.cnp;  }
            set { this.cnp = value; }
        }
        public string Nume
        {
            get { return this.nume; }
            set { this.nume = value; }
        }
        public byte Varsta
        {
            get { return this.varsta; }
            set { this.varsta = value; }
        }

        public override string ToString()
        {
            return this.nume + "  " + this.cnp + "  " + this.varsta;
        }
    }
}
