﻿using System;
using System.ComponentModel;
using ExempluMVVM.Model;
using ExempluMVVM.Commands;
using System.Collections.Generic;

namespace ExempluMVVM.ViewModel
{
    public class PersoanaVM : INotifyPropertyChanged
    {
        PersoanaServiciu persoanaServiciu;
        private Persoana persoanaCrt;
        private string mesaj;
        private string cnpCautat;
        private Comenzi adaugareComanda;
        private Comenzi actualizareComanda;
        private Comenzi stergereComanda;
        private Comenzi cautareComanda;

        public PersoanaVM()
        {
            this.persoanaCrt = new Persoana();
            this.persoanaServiciu = new PersoanaServiciu();
            this.ListaPersoane = this.persoanaServiciu.ListaPersoane;
            this.adaugareComanda = new Comenzi(this.Adaugare);
            this.actualizareComanda = new Comenzi(this.Actualizare);
            this.stergereComanda = new Comenzi(this.Stergere);
            this.cautareComanda = new Comenzi(this.Cautare);
            this.cnpCautat = "";
        }
        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged(string numeProprietate)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(numeProprietate));
        }
        public List<Persoana> ListaPersoane
        {
            get { return this.persoanaServiciu.ListaPersoane; }
            set { this.persoanaServiciu.ListaPersoane = value; OnPropertyChanged("ListaPersoane"); }
        }     

        public string Mesaj
        {
            get { return this.mesaj; }
            set { this.mesaj = value; OnPropertyChanged("Mesaj"); }
        }

        public string CnpCautat
        {
            get { return this.cnpCautat; }
            set { this.cnpCautat = value; }
        } 

        public Persoana PersoanaCrt
        {
            get { return this.persoanaCrt; }
            set { this.persoanaCrt = value;  }
        }

        public Comenzi AdaugareComanda
        {
            get { return this.adaugareComanda; }
        }

        public Comenzi ActualizareComanda
        {
            get { return this.actualizareComanda; }
        }

        public Comenzi StergereComanda
        {
            get { return this.stergereComanda; }
        }

        public Comenzi CautareComanda
        {
            get { return this.cautareComanda; }
        }       

        public void Adaugare()
        {
            try
            {
                bool succes = persoanaServiciu.Adauga(this.PersoanaCrt);
                if (succes)
                {
                    this.ListaPersoane = new List<Persoana>(this.persoanaServiciu.ListaPersoane);
                    this.Mesaj = "Persoana adaugata cu succes";  
                }                   
                else
                    this.Mesaj = "Esec adaugare persoana";
            }
            catch (Exception ex)
            {
                this.Mesaj = ex.Message;
            }
        }

        public void Actualizare()
        {
            try 
            {
                bool succes = persoanaServiciu.Actualizare(this.PersoanaCrt);
                if (succes)
                {
                    this.ListaPersoane = new List<Persoana>(this.persoanaServiciu.ListaPersoane);
                    this.Mesaj = "Persoana actualizata cu succes";
                }
                else
                    this.Mesaj = "Esec actualizare persoana";
            }
            catch (Exception ex)
            {
                this.Mesaj = ex.Message;
            }
        }

        public void Stergere()
        {
            try
            {
                if (this.cnpCautat != null && this.cnpCautat.Length > 0)
                {
                    bool succes = persoanaServiciu.Stergere(this.cnpCautat);
                    if (succes)
                    {
                        this.ListaPersoane = new List<Persoana>(this.persoanaServiciu.ListaPersoane);
                        this.Mesaj = "Persoana stearsa cu succes";
                    }
                    else
                        this.Mesaj = "Esec stergere persoana";
                }
                else
                    this.Mesaj = "CNP inexistent";
            }
            catch (Exception ex)
            {
                this.Mesaj = ex.Message;
            }
        }

        public void Cautare()
        {
            try
            {
                if (this.cnpCautat != null && this.cnpCautat.Length > 0)
                {
                    var pers = persoanaServiciu.Cautare(this.cnpCautat);
                    if (pers != null)
                        this.Mesaj = "Persoana gasita!  " + pers.ToString();
                    else
                        this.Mesaj = "Nu s-a gasit persoana!";
                }
                else
                    this.Mesaj = "CNP inexistent";
            }
            catch(Exception ex)
            {
                this.Mesaj = ex.Message;
            }
        }
    }
}
