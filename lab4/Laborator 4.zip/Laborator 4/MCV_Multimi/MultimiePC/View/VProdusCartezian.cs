﻿using System.Windows.Forms;

namespace MultimePC.View
{
    public partial class VProdusCartezian : Form
    {
        public VProdusCartezian()
        {
            InitializeComponent();
            this.lvMultimeA.View = System.Windows.Forms.View.Details;
            this.lvMultimeA.Columns.Add("Elemente", 160);
            this.lvMultimeB.View = System.Windows.Forms.View.Details;
            this.lvMultimeB.Columns.Add("Elemente", 160);
            this.lvProdusCartezian.View = System.Windows.Forms.View.Details;
            this.lvProdusCartezian.Columns.Add("Elemente", 300);
        }

        public Button AccesBtnMultimeA()
        {
            return this.btnMultimeA;
        }

        public Button AccesBtnMultimeB()
        {
            return this.btnMultimeB;
        }

        public Button AccesBtnReinitializare()
        {
            return this.btnReinitializare;
        }

        public ListView AccesLvMultimeA()
        {
            return this.lvMultimeA;
        }

        public ListView AccesLvMultimeB()
        {
            return this.lvMultimeB;
        }

        public ListView AccesLvProdusCartezian()
        {
            return this.lvProdusCartezian;
        }
    }
}
