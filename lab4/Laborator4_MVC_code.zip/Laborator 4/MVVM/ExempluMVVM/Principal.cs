﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using ExempluMVVM.ViewModel;

namespace ExempluMVVM
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class Principal : Window
    {
        PersoanaVM vmPersoana;
        public Principal()
        {
            InitializeComponent();
            vmPersoana = new PersoanaVM();
            this.DataContext = vmPersoana;
        }
    }
}
