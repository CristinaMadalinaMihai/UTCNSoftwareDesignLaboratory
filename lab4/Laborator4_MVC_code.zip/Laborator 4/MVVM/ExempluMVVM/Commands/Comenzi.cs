﻿using System;
using System.Windows.Input;

namespace ExempluMVVM.Commands
{
    public class Comenzi : ICommand
    {
        public event EventHandler CanExecuteChanged;
        private Action actiune;

        public Comenzi(Action actiune)
        {
            this.actiune = actiune;
        }

        public bool CanExecute(object parameter)
        {
            return true;
        }

        public void Execute(object parameter)
        {
            this.actiune();
        }
    }
}
