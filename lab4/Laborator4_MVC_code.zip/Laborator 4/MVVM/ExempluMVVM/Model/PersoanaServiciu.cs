﻿using System;
using System.Collections.Generic;
namespace ExempluMVVM.Model
{
    public class PersoanaServiciu
    {
        private List<Persoana> listaPersoane;

        public PersoanaServiciu()
        {
            this.listaPersoane = new List<Persoana>();
            this.listaPersoane.Add(new Persoana("Pop Ioan", "1971212345678", 25));
            this.listaPersoane.Add(new Persoana("Ion Ada", "2991025345678", 23));
        }

        public List<Persoana> ListaPersoane
        {
            get { return this.listaPersoane; }
            set { this.listaPersoane = value; }
        }

        public bool Adauga(Persoana persoana)
        {
            try
            {
                if (this.Cautare(persoana.Cnp) == null)
                {
                    this.listaPersoane.Add(new Persoana(persoana));
                    return true;
                }
                return false;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public bool Actualizare(Persoana persoana)
        {
            if (persoana.Nume != null && persoana.Nume.Trim().Length > 0)
            {
                for (int i = 0; i < this.listaPersoane.Count; i++)
                    if (this.listaPersoane[i].Cnp == persoana.Cnp)
                    {
                        this.listaPersoane[i].Nume = persoana.Nume;
                        this.listaPersoane[i].Varsta = persoana.Varsta;
                        return true;

                    }
            }
            return false;
        }

        public bool Stergere(string cnp)
        {
                for (int i = 0; i < this.listaPersoane.Count; i++)
                if (this.listaPersoane[i].Cnp == cnp)
                {
                    this.listaPersoane.RemoveAt(i);
                    return true;
                }
            return false;
        }

        public Persoana Cautare(string cnp)
        {
            if (cnp.Trim().Length > 0)
            {
                for (int i = 0; i < this.listaPersoane.Count; i++)
                    if (this.listaPersoane[i].Cnp == cnp)
                        return this.listaPersoane[i];
            } 
            return null;
        }
    }
}
