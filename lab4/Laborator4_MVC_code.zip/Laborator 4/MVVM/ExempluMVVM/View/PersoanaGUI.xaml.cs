﻿using System.Windows.Controls;

namespace ExempluMVVM.View
{
    /// <summary>
    /// Interaction logic for PersoanaGUI.xaml
    /// </summary>
    public partial class PersoanaGUI : UserControl
    {
        public PersoanaGUI()
        {
            InitializeComponent();
        }
    }
}
