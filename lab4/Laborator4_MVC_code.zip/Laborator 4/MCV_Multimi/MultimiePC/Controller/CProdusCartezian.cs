﻿using MultimePC.Model;
using MultimePC.View;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace MultimePC.Controller
{
    public class CProdusCartezian
    {
        private ProdusCartezian produsCartezian = null;
        private VProdusCartezian vPC = null;

        public CProdusCartezian()
        {
            this.vPC = new VProdusCartezian();
            this.produsCartezian = new ProdusCartezian();
            this.vPC.AccesBtnMultimeA().Click += new EventHandler(btnMultimeA_Click);
            this.vPC.AccesBtnMultimeB().Click += new EventHandler(btnMultimeB_Click);
            this.vPC.AccesBtnReinitializare().Click += new EventHandler(btnReinitializare_Click);
        }

        public VProdusCartezian AccesView()
        {
            return this.vPC; 
        }    

        private void btnMultimeA_Click(object sender, EventArgs e)
        {
            this.produsCartezian.GenerareMultimeA();
            this.setareLista(this.produsCartezian.MultimeA.Elemente, this.vPC.AccesLvMultimeA().Items);
            this.setareListaRezultat(this.produsCartezian.Produscartezian, this.vPC.AccesLvProdusCartezian().Items);
        }

        private void btnMultimeB_Click(object sender, EventArgs e)
        {
            this.produsCartezian.GenerareMultimeB();
            this.setareLista(this.produsCartezian.MultimeB.Elemente, this.vPC.AccesLvMultimeB().Items);
            this.setareListaRezultat(this.produsCartezian.Produscartezian, this.vPC.AccesLvProdusCartezian().Items);
        }

        private void btnReinitializare_Click(object sender, EventArgs e)
        {
            this.produsCartezian = new ProdusCartezian();
            this.setareLista(this.produsCartezian.MultimeA.Elemente, this.vPC.AccesLvMultimeA().Items);
            this.setareLista(this.produsCartezian.MultimeB.Elemente, this.vPC.AccesLvMultimeB().Items);
            this.setareListaRezultat(this.produsCartezian.Produscartezian, this.vPC.AccesLvProdusCartezian().Items);
        }

        private void setareLista(SortedSet<int> multime, ListView.ListViewItemCollection colectie)
        {           
            colectie.Clear();
            foreach (int element in multime)
            {
                ListViewItem item = new ListViewItem(element.ToString());
                colectie.Add(item);
            }
        } 

        private void setareListaRezultat(List<Tuple<int, int>> lista, ListView.ListViewItemCollection colectie)
        {
            colectie.Clear();
            foreach (Tuple<int, int> element in lista)
            {
                ListViewItem item = new ListViewItem(element.ToString());
                colectie.Add(item);
            }
        }
    }
}
