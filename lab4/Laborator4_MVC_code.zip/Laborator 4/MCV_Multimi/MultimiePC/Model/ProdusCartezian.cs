﻿using System;
using System.Collections.Generic;

namespace MultimePC.Model
{
    public class ProdusCartezian
    {
        private Multime multimeA;
        private Multime multimeB;
        private List<Tuple<int, int>> produsCartezian;

        public ProdusCartezian()
        {
            this.multimeA = new Multime();
            this.multimeB = new Multime();
            this.produsCartezian = new List<Tuple<int, int>>();
        } 

        public Multime MultimeA
        {
            get { return this.multimeA; }
        }

        public Multime MultimeB
        {
            get { return this.multimeB; } 
        }

        public List<Tuple<int, int>> Produscartezian
        {
            get { return this.produsCartezian; }
        }

        public void GenerareMultimeA()
        {
            this.multimeA.GenerareMultime();
            this.calculProdusCartezian();
        }

        public void GenerareMultimeB()
        {
            this.multimeB.GenerareMultime();
            this.calculProdusCartezian();
        }

        private void calculProdusCartezian()
        {
            this.produsCartezian = new List<Tuple<int, int>>();
            foreach (int a in this.multimeA.Elemente)
            {
                foreach (int b in this.multimeB.Elemente)
                {
                    Tuple<int, int> element = new Tuple<int, int>(a, b);
                    this.produsCartezian.Add(element);
                }
            }
        }
    }
}
