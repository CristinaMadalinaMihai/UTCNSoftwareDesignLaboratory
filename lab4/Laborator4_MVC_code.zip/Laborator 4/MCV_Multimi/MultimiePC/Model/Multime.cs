﻿using System;
using System.Collections.Generic;

namespace MultimePC.Model
{
    public class Multime
    {
        private SortedSet<int> elemente; 

        public Multime()  // multime vida
        {
            this.elemente = new SortedSet<int>();
        }

        public SortedSet<int> Elemente
        {
            get { return this.elemente; }
        }

        public void GenerareMultime()
        {
            this.elemente = new SortedSet<int>();
            Random r = new Random();
            int cardinal = r.Next(1, 21);
            for (int i = 1; i <= cardinal; i++)
            {
                int nr = r.Next(0, 1000);
                this.elemente.Add(nr);
            }
        }    
    }
}
