﻿
namespace MultimePC.View
{
    partial class VProdusCartezian
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lvMultimeA = new System.Windows.Forms.ListView();
            this.lvMultimeB = new System.Windows.Forms.ListView();
            this.lvProdusCartezian = new System.Windows.Forms.ListView();
            this.btnMultimeA = new System.Windows.Forms.Button();
            this.btnMultimeB = new System.Windows.Forms.Button();
            this.eticheta = new System.Windows.Forms.Label();
            this.btnReinitializare = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lvMultimeA
            // 
            this.lvMultimeA.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lvMultimeA.HideSelection = false;
            this.lvMultimeA.Location = new System.Drawing.Point(29, 52);
            this.lvMultimeA.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lvMultimeA.Name = "lvMultimeA";
            this.lvMultimeA.Size = new System.Drawing.Size(82, 240);
            this.lvMultimeA.TabIndex = 0;
            this.lvMultimeA.UseCompatibleStateImageBehavior = false;
            // 
            // lvMultimeB
            // 
            this.lvMultimeB.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lvMultimeB.HideSelection = false;
            this.lvMultimeB.Location = new System.Drawing.Point(165, 52);
            this.lvMultimeB.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lvMultimeB.Name = "lvMultimeB";
            this.lvMultimeB.Size = new System.Drawing.Size(82, 240);
            this.lvMultimeB.TabIndex = 1;
            this.lvMultimeB.UseCompatibleStateImageBehavior = false;
            // 
            // lvProdusCartezian
            // 
            this.lvProdusCartezian.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lvProdusCartezian.HideSelection = false;
            this.lvProdusCartezian.Location = new System.Drawing.Point(301, 52);
            this.lvProdusCartezian.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lvProdusCartezian.Name = "lvProdusCartezian";
            this.lvProdusCartezian.Size = new System.Drawing.Size(149, 240);
            this.lvProdusCartezian.TabIndex = 2;
            this.lvProdusCartezian.UseCompatibleStateImageBehavior = false;
            // 
            // btnMultimeA
            // 
            this.btnMultimeA.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMultimeA.Location = new System.Drawing.Point(20, 22);
            this.btnMultimeA.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnMultimeA.Name = "btnMultimeA";
            this.btnMultimeA.Size = new System.Drawing.Size(101, 25);
            this.btnMultimeA.TabIndex = 3;
            this.btnMultimeA.Text = "MULTIME A";
            this.btnMultimeA.UseVisualStyleBackColor = true;
            // 
            // btnMultimeB
            // 
            this.btnMultimeB.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMultimeB.Location = new System.Drawing.Point(154, 22);
            this.btnMultimeB.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnMultimeB.Name = "btnMultimeB";
            this.btnMultimeB.Size = new System.Drawing.Size(101, 25);
            this.btnMultimeB.TabIndex = 4;
            this.btnMultimeB.Text = "MULTIME B";
            this.btnMultimeB.UseVisualStyleBackColor = true;
            // 
            // eticheta
            // 
            this.eticheta.AutoSize = true;
            this.eticheta.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.eticheta.Location = new System.Drawing.Point(287, 25);
            this.eticheta.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.eticheta.Name = "eticheta";
            this.eticheta.Size = new System.Drawing.Size(175, 18);
            this.eticheta.TabIndex = 5;
            this.eticheta.Text = "PRODUS CARTEZIAN";
            // 
            // btnReinitializare
            // 
            this.btnReinitializare.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReinitializare.Location = new System.Drawing.Point(291, 316);
            this.btnReinitializare.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnReinitializare.Name = "btnReinitializare";
            this.btnReinitializare.Size = new System.Drawing.Size(159, 30);
            this.btnReinitializare.TabIndex = 6;
            this.btnReinitializare.Text = "REINITIALIZARE";
            this.btnReinitializare.UseVisualStyleBackColor = true;
            // 
            // VProdusCartezian
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(479, 370);
            this.Controls.Add(this.btnReinitializare);
            this.Controls.Add(this.eticheta);
            this.Controls.Add(this.btnMultimeB);
            this.Controls.Add(this.btnMultimeA);
            this.Controls.Add(this.lvProdusCartezian);
            this.Controls.Add(this.lvMultimeB);
            this.Controls.Add(this.lvMultimeA);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "VProdusCartezian";
            this.Text = "PRODUS CARTEZIAN";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView lvMultimeA;
        private System.Windows.Forms.ListView lvMultimeB;
        private System.Windows.Forms.ListView lvProdusCartezian;
        private System.Windows.Forms.Button btnMultimeA;
        private System.Windows.Forms.Button btnMultimeB;
        private System.Windows.Forms.Label eticheta;
        private System.Windows.Forms.Button btnReinitializare;
    }
}