﻿using MultimePC.Controller;
using System.Windows.Forms;

namespace MultimiePC
{
    public class Principal
    {
        static void Main(string[] args)
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            CProdusCartezian cPC = new CProdusCartezian();
            Application.Run(cPC.AccesView());
        }
    }
}
