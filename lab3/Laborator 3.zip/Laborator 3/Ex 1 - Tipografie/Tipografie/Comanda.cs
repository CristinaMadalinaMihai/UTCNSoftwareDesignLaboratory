﻿using System;
using System.Collections.Generic;

namespace Tipografie
{
    public class Comanda
    {
        private int numarComanda;
        private DateTime dataComanda;
        private Client client;
        private List<ServiciuComandat> serviciiComandate;
        private float discount;
        private bool finalizata;

        public Comanda()
        {
            this.numarComanda = 1;
            this.dataComanda = DateTime.Now;
            this.client = new Client();
            this.serviciiComandate = new List<ServiciuComandat>();
            this.discount = 0;
            this.finalizata = false;
        }

        /*public Comanda(int numarComanda, Client client)
        {
            this.numarComanda = numarComanda;
            this.dataComanda = DateTime.Now;
            this.client = client;
            this.serviciiComandate = new List<ServiciuComandat>();
            this.discount = 0;
            this.finalizata = false;
        }*/

        public Comanda(int numarComanda, string nume, string numarTelefon, string adresaMail, string cnp)
        {
            this.numarComanda = numarComanda;    
            this.dataComanda = DateTime.Now;
            this.client = new Client(nume, numarTelefon, adresaMail, cnp);
            this.serviciiComandate = new List<ServiciuComandat>();
            this.discount = 0;
            this.finalizata = false;
        } 

        public void AdaugareServiciuComandat(string denumire, float pretUnitar, int cantitate, float discount)
        {
            ServiciuComandat sc = new ServiciuComandat(denumire, pretUnitar, cantitate, discount);
            this.serviciiComandate.Add(sc);
        }

        public int NumarComanda
        {
            get { return this.numarComanda; }
            set { this.numarComanda = value; }
        }

        public DateTime DataComanda
        {
            get { return this.dataComanda; }
        }

        public Client Client
        {
            get { return this.client; }
        }
        public List<ServiciuComandat> ServiciiComandate
        {
            get { return this.serviciiComandate; }
        }

        public float Discount
        {
            get { return this.discount; }
            set { this.discount = value; }
        }

        public bool Finalizata
        {
            get { return this.finalizata; }
        }

        public void ActualizareDataComanda(int an, int luna, int zi)
        {
            this.dataComanda = new DateTime(an, luna, zi); 
        }

        public override string ToString()
        {
            string s = "Comanda " + this.numarComanda;
            s += " din data " + this.dataComanda.ToShortDateString();
            s += "\n Client: " + this.client.ToString();
            s += "\n Lista serviciilor comandate:";
            foreach (ServiciuComandat sc in this.serviciiComandate)
                s += "\n   " + sc.ToString();
            s += "\n Discount: " + this.discount;
            s += "\n Pret comanda = " + this.PretComanda();
            return s;
        }

        public float PretComanda()
        {
            float pret = 0;
            foreach (ServiciuComandat sc in this.serviciiComandate)
                pret += sc.PretServiciuComandat();
            pret -= pret * discount/100;
            return pret;
        }

        public void GenerareFactura()
        {
            this.finalizata = true;
            Factura factura = new Factura(this.numarComanda, this.client.ToString(), this.PretComanda());
            factura.GenerareFactura();
        }
    }
}
