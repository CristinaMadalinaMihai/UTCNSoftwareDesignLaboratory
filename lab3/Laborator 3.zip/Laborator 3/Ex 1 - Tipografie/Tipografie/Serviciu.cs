﻿namespace Tipografie
{
    public class Serviciu
    {
        private string denumire;
        private float pretUnitar;
        public Serviciu()
        {
            this.denumire = "tiparire";
            this.pretUnitar = 1;
        }
        public Serviciu(string denumire, float pretUnitar)
        {
            this.denumire = denumire;
            this.pretUnitar = pretUnitar;
        }
        public string Denumire
        {
            get { return this.denumire; }
            set { this.denumire = value; }
        }
        public float PretUnitar
        {
            get { return this.pretUnitar; }
            set { this.pretUnitar = value; }
        } 

        public override string ToString()
        {
            return this.denumire + " Pret unitar = " + this.pretUnitar;
        } 
    }
}
