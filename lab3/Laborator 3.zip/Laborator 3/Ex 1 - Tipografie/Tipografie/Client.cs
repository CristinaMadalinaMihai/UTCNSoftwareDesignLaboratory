﻿namespace Tipografie
{
    public class Client
    {
        private string nume;
        private string numarTelefon;
        private string adresaMail;
        private string cnp;

        public Client()
        {
            this.nume = "Pop Ioan";
            this.numarTelefon = "0712345678";
            this.adresaMail = "ioan.pop@abc.ro";
            this.cnp = "1971212345678";
        }

        public Client(string nume, string numarTelefon, string adresaMail, string cnp)
        {
            this.nume = nume;
            this.numarTelefon = numarTelefon;
            this.adresaMail = adresaMail;
            this.cnp = cnp;
        }

        public string Nume
        {
            get { return this.nume; }
            set { this.nume = value; }
        }

        public string NumarTelefon
        {
            get { return this.numarTelefon; }
            set { this.numarTelefon = value; }
        }

        public string AdresaMail
        {
            get { return this.adresaMail; }
            set { this.adresaMail = value; } 
        }
        public string Cnp
        {
            get { return this.cnp; }
            set { this.cnp = value; }
        }

        public override string ToString()
        {
            string s = this.nume + " CNP: " + this.cnp;
            s += " Nr. telefon: " + this.numarTelefon;
            s += " eMail: " + this.adresaMail;
            return s;
        }
    }
}
