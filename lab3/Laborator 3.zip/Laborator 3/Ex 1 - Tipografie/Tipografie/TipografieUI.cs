﻿namespace Tipografie
{
    public class TipografieUI
    {
        private TipografieControl tc; 

        public void AdaugareComanda()
        {
            this.tc.CreareComanda(1, "Pop Ioan", "0712345678", "ioan.pop@abc.ro", "1971212345678");
            this.tc.AdaugareServiciuComandat("lipire", 5, 10, 1);
            this.tc.AdaugareServiciuComandat("tiparire", 1, 1, 0);
            this.tc.AdaugareServiciuComandat("legare", 2, 1, 0);
            this.tc.ActualizareDiscount(2);
            this.tc.ActualizareDataComanda(2022, 12, 22);
            this.tc.AfisareComanda();
        }

        public void FinalizareComanda()
        {
            this.tc.FinalizareComanda();
        }

        public TipografieUI()
        {
            this.tc = new TipografieControl();
            this.AdaugareComanda();
            this.FinalizareComanda();
        }
    }
}
