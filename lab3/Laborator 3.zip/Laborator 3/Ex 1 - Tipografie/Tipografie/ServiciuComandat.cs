﻿namespace Tipografie
{
    public class ServiciuComandat
    {
        private Serviciu serviciu;
        private int cantitate;
        private float discount;
        public ServiciuComandat()
        {
            this.serviciu = new Serviciu();
            this.cantitate = 1;
            this.discount = 0;
        }
        public ServiciuComandat(string denumire, float pretUnitar, int cantitate, float discount)
        {
            this.serviciu = new Serviciu(denumire, pretUnitar); ;
            this.cantitate = cantitate;
            this.discount = discount;
        }
        public Serviciu Serviciu
        {
            get { return this.serviciu; } 
        }

        public int Cantitate
        {
            get { return this.cantitate; }
            set { this.cantitate = value; }
        }

        public float Discount
        {
            get { return this.discount; }
            set { this.discount = value; }
        }

        public override string ToString()
        {
            string s = "Serviciu comandat: " + this.serviciu.ToString();
            s += " Cantitate = " + this.cantitate;
            s += " Discount = " + this.discount;
            s += " Pret serviciu comandat = " + this.PretServiciuComandat();
            return s;
        }

        public float PretServiciuComandat()
        {
            float pret = this.cantitate * this.serviciu.PretUnitar;
            pret -= pret * this.discount/100;
            return pret;
        }
    }
}
