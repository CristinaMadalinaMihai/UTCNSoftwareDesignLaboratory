﻿using System;
using System.IO;

namespace Tipografie
{
    public class Factura
    {
        private int numarFactura;
        private string dateClient;
        private DateTime dataFactura;
        private float valoare; 

        public Factura(int numarFactura, string dateClient, float valoare)
        {
            this.numarFactura = numarFactura;
            this.dateClient = dateClient;
            this.dataFactura = DateTime.Now;
            this.valoare = valoare;
        }

        public int NumarFactura
        {
            get { return this.numarFactura; }
            set { this.numarFactura = value; }
        }

        public float Valoare
        {
            get { return this.valoare; }
        }

        public DateTime DataFactura
        {
            get { return this.dataFactura; }
        }

        public string DateClient
        {
            get { return this.dateClient; }
        }

        public override string ToString()
        {
            string s = "Factura " + this.numarFactura;
            s += " din data " + this.dataFactura.ToShortDateString();
            s += "\n Date Client: " + this.dateClient;
            s += "\n Date Tipografie ";
            s += "\n Valoare factura = " + this.valoare + " RON";
            return s;
        }

        public void GenerareFactura()
        {
            File.WriteAllText("D:\\Factura.txt", this.ToString());
        }
    }
}
