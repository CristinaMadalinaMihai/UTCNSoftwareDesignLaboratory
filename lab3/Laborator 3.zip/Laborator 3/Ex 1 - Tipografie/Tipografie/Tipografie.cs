﻿namespace Tipografie
{
    class Tipografie
    {
        static void Main(string[] args)
        {
            TipografieUI ui = new TipografieUI();
        }
    }
}
