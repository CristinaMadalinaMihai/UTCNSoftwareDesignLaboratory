﻿using System;

namespace Tipografie
{
    public class TipografieControl
    {
        private Comanda comanda;
        public void CreareComanda(int numarComanda, string nume, string numarTelefon, string adresaMail, string cnp)
        {
            this.comanda = new Comanda(numarComanda, nume, numarTelefon, adresaMail, cnp);
        }

        public void AdaugareServiciuComandat(string denumire, float pretUnitar, int cantitate, float discount)
        {
            this.comanda.AdaugareServiciuComandat(denumire, pretUnitar, cantitate, discount);
        }

        public void ActualizareDataComanda(int an, int luna, int zi)
        {
            this.comanda.ActualizareDataComanda(an, luna, zi);
        }

        public void ActualizareDiscount(float discount)
        {
            this.comanda.Discount = discount;
        }

        public void FinalizareComanda()
        {
            this.comanda.GenerareFactura();
        }

        public void AfisareComanda()
        {
            Console.WriteLine(this.comanda.ToString());
        }
    }
}
