﻿using Medii.View;
using System.Windows.Forms;

namespace Medii
{
    class Principal
    {
        static void Main(string[] args)
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MediiGUI());
        }
    }
} 
