﻿using System;

namespace Medii.Model
{
    public class MediaGeometrica : Media
    {
        public MediaGeometrica() : base() { }

        public MediaGeometrica(double nr1, double nr2) : base(nr1, nr2) { }

        public MediaGeometrica(MediaGeometrica ma)
        {
            this.numar1 = ma.numar1;
            this.numar2 = ma.numar2;
        }

        public override double CalculMedie()
        {
            return Math.Sqrt(this.numar1 * this.numar2);
        }
    }
}
