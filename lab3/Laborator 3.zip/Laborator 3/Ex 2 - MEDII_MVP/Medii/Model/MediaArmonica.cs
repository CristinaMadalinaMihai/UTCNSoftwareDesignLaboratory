﻿namespace Medii.Model
{
    public class MediaArmonica : Media
    {
        public MediaArmonica() : base() { }

        public MediaArmonica(double nr1, double nr2) : base(nr1, nr2) { }

        public MediaArmonica(MediaArmonica ma)
        {
            this.numar1 = ma.numar1;
            this.numar2 = ma.numar2;
        }

        public override double CalculMedie()
        {
            return 2/(1/this.numar1 + 1/this.numar2);
        }
    }
}
