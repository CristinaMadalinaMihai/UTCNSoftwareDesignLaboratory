﻿namespace Medii.Model
{
    public abstract class Media
    {
        protected double numar1;
        protected double numar2;

        public Media()
        {
            this.numar1 = 1;
            this.numar2 = 1;
        }

        public Media(double nr1, double nr2)
        {
            this.numar1 = nr1;
            this.numar2 = nr2;
        }

        public Media(Media m)
        {
            this.numar1 = m.numar1;
            this.numar2 = m.numar2;
        }

        public double Numar1
        {
            get { return this.numar1; }
            set { this.numar1 = value; }
        }

        public double Numar2
        {
            get { return this.numar2; }
            set { this.numar2 = value; }
        }

        public abstract double CalculMedie();
    }
}
