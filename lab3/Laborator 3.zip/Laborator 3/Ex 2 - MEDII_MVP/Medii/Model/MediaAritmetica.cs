﻿namespace Medii.Model
{
    public class MediaAritmetica : Media
    {
        public MediaAritmetica() : base() { }

        public MediaAritmetica(double nr1, double nr2) : base(nr1, nr2) { }

        public MediaAritmetica(MediaAritmetica ma)
        {
            this.numar1 = ma.numar1;
            this.numar2 = ma.numar2;
        }

        public override double CalculMedie()
        {
            return (this.numar1 + this.numar2) / 2;
        }
    }
}
