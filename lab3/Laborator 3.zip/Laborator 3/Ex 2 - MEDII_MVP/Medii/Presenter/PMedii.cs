﻿using Medii.Model;
using Medii.View;
using System;

namespace Medii.Presenter
{
    public class PMedii
    {
        private IMedii imedii;
        private Media medie = null;
        
        public PMedii(IMedii imedii)
        {
            this.imedii = imedii;
        }

        public void Calcul()
        {   
            try
            {
                double nr1, nr2, ma, mg, mh;
                nr1 = double.Parse(this.imedii.AccesNumar1());
                nr2 = double.Parse(this.imedii.AccesNumar2());
                this.medie = new MediaAritmetica(nr1, nr2);
                ma = this.medie.CalculMedie(); 
                this.imedii.ActualizareMA(ma.ToString());
                if (nr1 * nr2 >= 0) 
                {
                    this.medie = new MediaGeometrica(nr1, nr2);
                    mg = this.medie.CalculMedie();
                    this.imedii.ActualizareMG(mg.ToString());
                }
                else
                    this.imedii.ActualizareMG("Nu se poate calcula.");
                if (nr1 != 0 && nr2 != 0)
                {
                    this.medie = new MediaArmonica(nr1, nr2);
                    mh = this.medie.CalculMedie();
                    this.imedii.ActualizareMH(mh.ToString());
                }
                else
                    this.imedii.ActualizareMH("Nu se poate calcula.");
            }
            catch (Exception)
            {
                this.Reinitializare();
            }
        }

        public void Reinitializare()
        {
            this.imedii.ActualizareNumar1("");
            this.imedii.ActualizareNumar2("");
            this.imedii.ActualizareMA("");
            this.imedii.ActualizareMG("");
            this.imedii.ActualizareMH("");
        }

    }
}
