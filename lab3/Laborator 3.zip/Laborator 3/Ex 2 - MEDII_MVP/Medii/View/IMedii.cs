﻿namespace Medii.View
{
    public interface IMedii
    {
        string AccesNumar1();
        void ActualizareNumar1(string nr1);
        string AccesNumar2();
        void ActualizareNumar2(string nr2);
        void ActualizareMA(string ma);
        void ActualizareMG(string mg);
        void ActualizareMH(string mh);
    }
}
