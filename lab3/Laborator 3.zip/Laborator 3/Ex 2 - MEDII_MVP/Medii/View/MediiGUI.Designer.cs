﻿
namespace Medii.View
{
    partial class MediiGUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtNr1 = new System.Windows.Forms.TextBox();
            this.txtNr2 = new System.Windows.Forms.TextBox();
            this.txtMA = new System.Windows.Forms.TextBox();
            this.txtMG = new System.Windows.Forms.TextBox();
            this.txtMH = new System.Windows.Forms.TextBox();
            this.btnCalcul = new System.Windows.Forms.Button();
            this.btnReinitializare = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.RoyalBlue;
            this.label1.Location = new System.Drawing.Point(46, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(111, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "Numar 1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.RoyalBlue;
            this.label2.Location = new System.Drawing.Point(46, 88);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(111, 29);
            this.label2.TabIndex = 1;
            this.label2.Text = "Numar 2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.RoyalBlue;
            this.label3.Location = new System.Drawing.Point(46, 264);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(206, 29);
            this.label3.TabIndex = 2;
            this.label3.Text = "Media aritmetica";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.RoyalBlue;
            this.label4.Location = new System.Drawing.Point(46, 320);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(223, 29);
            this.label4.TabIndex = 3;
            this.label4.Text = "Media geometrica";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.RoyalBlue;
            this.label5.Location = new System.Drawing.Point(46, 375);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(199, 29);
            this.label5.TabIndex = 4;
            this.label5.Text = "Media armonica";
            // 
            // txtNr1
            // 
            this.txtNr1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNr1.ForeColor = System.Drawing.Color.RoyalBlue;
            this.txtNr1.Location = new System.Drawing.Point(210, 31);
            this.txtNr1.Name = "txtNr1";
            this.txtNr1.Size = new System.Drawing.Size(191, 34);
            this.txtNr1.TabIndex = 5;
            // 
            // txtNr2
            // 
            this.txtNr2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNr2.ForeColor = System.Drawing.Color.RoyalBlue;
            this.txtNr2.Location = new System.Drawing.Point(210, 85);
            this.txtNr2.Name = "txtNr2";
            this.txtNr2.Size = new System.Drawing.Size(191, 34);
            this.txtNr2.TabIndex = 6;
            // 
            // txtMA
            // 
            this.txtMA.Enabled = false;
            this.txtMA.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMA.ForeColor = System.Drawing.Color.RoyalBlue;
            this.txtMA.Location = new System.Drawing.Point(282, 259);
            this.txtMA.Name = "txtMA";
            this.txtMA.Size = new System.Drawing.Size(119, 34);
            this.txtMA.TabIndex = 7;
            // 
            // txtMG
            // 
            this.txtMG.Enabled = false;
            this.txtMG.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMG.ForeColor = System.Drawing.Color.RoyalBlue;
            this.txtMG.Location = new System.Drawing.Point(282, 320);
            this.txtMG.Name = "txtMG";
            this.txtMG.Size = new System.Drawing.Size(119, 34);
            this.txtMG.TabIndex = 8;
            // 
            // txtMH
            // 
            this.txtMH.Enabled = false;
            this.txtMH.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMH.ForeColor = System.Drawing.Color.RoyalBlue;
            this.txtMH.Location = new System.Drawing.Point(282, 372);
            this.txtMH.Name = "txtMH";
            this.txtMH.Size = new System.Drawing.Size(119, 34);
            this.txtMH.TabIndex = 9;
            // 
            // btnCalcul
            // 
            this.btnCalcul.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcul.ForeColor = System.Drawing.Color.RoyalBlue;
            this.btnCalcul.Location = new System.Drawing.Point(23, 172);
            this.btnCalcul.Name = "btnCalcul";
            this.btnCalcul.Size = new System.Drawing.Size(134, 39);
            this.btnCalcul.TabIndex = 10;
            this.btnCalcul.Text = "CALCUL";
            this.btnCalcul.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnCalcul.UseVisualStyleBackColor = true;
            this.btnCalcul.Click += new System.EventHandler(this.btnCalcul_Click);
            // 
            // btnReinitializare
            // 
            this.btnReinitializare.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReinitializare.ForeColor = System.Drawing.Color.RoyalBlue;
            this.btnReinitializare.Location = new System.Drawing.Point(210, 172);
            this.btnReinitializare.Name = "btnReinitializare";
            this.btnReinitializare.Size = new System.Drawing.Size(239, 39);
            this.btnReinitializare.TabIndex = 11;
            this.btnReinitializare.Text = "REINITIALIZARE";
            this.btnReinitializare.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnReinitializare.UseVisualStyleBackColor = true;
            this.btnReinitializare.Click += new System.EventHandler(this.btnReinitializare_Click);
            // 
            // MediiGUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(467, 430);
            this.Controls.Add(this.btnReinitializare);
            this.Controls.Add(this.btnCalcul);
            this.Controls.Add(this.txtMH);
            this.Controls.Add(this.txtMG);
            this.Controls.Add(this.txtMA);
            this.Controls.Add(this.txtNr2);
            this.Controls.Add(this.txtNr1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.ForeColor = System.Drawing.Color.RoyalBlue;
            this.MaximizeBox = false;
            this.Name = "MediiGUI";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CALCUL MEDII";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtNr1;
        private System.Windows.Forms.TextBox txtNr2;
        private System.Windows.Forms.TextBox txtMA;
        private System.Windows.Forms.TextBox txtMG;
        private System.Windows.Forms.TextBox txtMH;
        private System.Windows.Forms.Button btnCalcul;
        private System.Windows.Forms.Button btnReinitializare;
    }
}