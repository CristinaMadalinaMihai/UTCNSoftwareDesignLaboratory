﻿using Medii.Presenter;
using System;
using System.Windows.Forms;

namespace Medii.View
{
    public partial class MediiGUI : Form, IMedii
    {
        PMedii pm =null;
        public MediiGUI()
        {
            InitializeComponent();
            pm = new PMedii(this);
        }

        public string AccesNumar1()
        {
            return this.txtNr1.Text;
        }

        public string AccesNumar2()
        {
            return this.txtNr2.Text;
        }

        public void ActualizareMA(string ma)
        {
            this.txtMA.Text = ma;
        }

        public void ActualizareMG(string mg)
        {
            this.txtMG.Text = mg;
        }

        public void ActualizareMH(string mh)
        {
            this.txtMH.Text = mh;
        }

        public void ActualizareNumar1(string nr1)
        {
            this.txtNr1.Text = nr1;
        }

        public void ActualizareNumar2(string nr2)
        {
            this.txtNr2.Text = nr2;
        }

        private void btnCalcul_Click(object sender, EventArgs e)
        { 
            this.pm.Calcul();
        }

        private void btnReinitializare_Click(object sender, EventArgs e)
        {
            this.pm.Reinitializare(); 
        }

    }
}
