﻿using BusinessLogic.Contracts;
using BusinessLogic.Contracts.Services;
using BusinessLogic.Services;
using Microsoft.Practices.Unity;
using Prism.Modularity;

namespace BusinessLogic
{
    public class BusinessLogicModule : IModule
    {
        readonly IUnityContainer _container;
        public BusinessLogicModule(IUnityContainer container)
        {
            _container = container;
        }

        public void Initialize()
        {
            _container.RegisterType<IBookService, BookService>();
            _container.RegisterType<IBookMapper, BookMapper>();
        }
    }
}
