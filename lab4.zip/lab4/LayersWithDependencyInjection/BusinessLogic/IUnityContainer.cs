﻿namespace BusinessLogic
{
    internal interface IUnityContainer
    {
    }
}